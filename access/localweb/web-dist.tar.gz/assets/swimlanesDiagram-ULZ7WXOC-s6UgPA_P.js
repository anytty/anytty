import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cuv8ii2O.js";import"./chunk-I66GZJ75-B7553xaJ.js";import"./chunk-NSK5VX7P-Cut1DaF2.js";import"./chunk-4I5QYGJK-BezN6tGE.js";import"./chunk-WRU74C26-CB4WS8eE.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-DmrJNZ2f.js";import"./chunk-2GRJ4B5K-CXD4qEkp.js";import"./chunk-XXDRQBXY-DIyncvop.js";import"./chunk-KBJHAD2P-VLg80Bnp.js";import"./chunk-W5SLKNZC-De3nyNwA.js";import"./chunk-QR6OTTB3-JSHrCBj2.js";import"./chunk-7Z6QIM7H-9-3-FBsD.js";import{r as t,t as n}from"./chunk-JQJVKLGR-CZY2Xq-y.js";import"./mermaid.core-vi78-8bv.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};