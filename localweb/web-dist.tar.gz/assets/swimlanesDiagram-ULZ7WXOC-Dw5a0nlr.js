import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cj2G53Cs.js";import"./chunk-I66GZJ75-Dg6lrOae.js";import"./chunk-NSK5VX7P-BjDVHhRl.js";import"./chunk-4I5QYGJK-CxmiQrqn.js";import"./chunk-WRU74C26-BBprhjjn.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-CZHEwKN4.js";import"./chunk-2GRJ4B5K-ob8jcFDo.js";import"./chunk-XXDRQBXY-UWe6J0Wy.js";import"./chunk-KBJHAD2P-Bnb6rLj-.js";import"./chunk-W5SLKNZC-C6OTbZ47.js";import"./chunk-QR6OTTB3-DTX5Qo-5.js";import"./chunk-7Z6QIM7H-BkmOyLCj.js";import"./chunk-J7OUQ5F2-FziKAsQt.js";import"./chunk-ZIRB5QZD-C6fEPe3t.js";import{r as t,t as n}from"./chunk-JQJVKLGR-arXqcSL8.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};