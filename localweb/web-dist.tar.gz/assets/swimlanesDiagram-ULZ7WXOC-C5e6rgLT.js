import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cuv8ii2O.js";import"./chunk-I66GZJ75-CSw9quQz.js";import"./chunk-NSK5VX7P-G3C8G-kI.js";import"./chunk-4I5QYGJK-BRuNg_Sq.js";import"./chunk-WRU74C26-CdOyGirt.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-z3f2F97K.js";import"./chunk-2GRJ4B5K-BobmAw_l.js";import"./chunk-XXDRQBXY-DIyncvop.js";import"./chunk-KBJHAD2P-DhgX0krl.js";import"./chunk-W5SLKNZC-C8sv20l-.js";import"./chunk-QR6OTTB3-BlgNyaHT.js";import"./chunk-7Z6QIM7H-i_Q098Ir.js";import{r as t,t as n}from"./chunk-JQJVKLGR-Du9vcooM.js";import"./mermaid.core-Bnx2xunN.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};