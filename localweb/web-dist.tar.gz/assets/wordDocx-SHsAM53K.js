const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/docx-preview-DozafL5x.js","assets/rolldown-runtime-CNC7AqOf.js","assets/lib-Fs3kAoKL.js","assets/__vite-browser-external-BkN3LSWE.js"])))=>i.map(i=>d[i]);
import{a as e}from"./rolldown-runtime-CNC7AqOf.js";import{t}from"./preload-helper-Czpn1I53.js";import{D as n,O as r,j as i}from"./dist-DZoE9tDK.js";import{d as a,i as o,m as s,r as c}from"./fit-DfSEv7XR.js";import{i as l,n as u,r as d,t as f}from"./printLayout-B9g6jJOI.js";import{t as p}from"./messages-1MdUPZRw.js";import{t as m}from"./options-BuSsAvCB.js";import{t as h}from"./lib-Fs3kAoKL.js";var g=e(h(),1),_={width:794,height:1123},v=new Set([`file:`,`about:`,`data:`]),y=.24,b=3,x=.15,S=`0.3.26`,C=20555,w=`http://schemas.openxmlformats.org/wordprocessingml/2006/main`,T=`http://schemas.openxmlformats.org/officeDocument/2006/relationships`,E=`http://schemas.openxmlformats.org/package/2006/relationships`,D=`urn:schemas-microsoft-com:vml`,O=`word/document.xml`,k=`word/_rels/document.xml.rels`,A=`docx-page-background`,ee={bmp:`image/bmp`,gif:`image/gif`,jpeg:`image/jpeg`,jpg:`image/jpeg`,png:`image/png`,svg:`image/svg+xml`,tif:`image/tiff`,tiff:`image/tiff`,webp:`image/webp`},j=e=>{let t=typeof e.renderAsync==`function`?e:e.default;if(!t||typeof t.renderAsync!=`function`)throw TypeError(`@file-viewer/docx did not expose a compatible renderAsync function.`);return t},M=(()=>{let e={module:null,async load(){return this.module||=t(()=>import(`./docx-preview-DozafL5x.js`),__vite__mapDeps([0,1,2,3])),this.module}};return async()=>j(await e.load())})(),N=e=>e instanceof Error&&/(?:undefined|null).*children|children.*(?:undefined|null)/i.test(e.message)&&/renderHeaderFooter/i.test(e.stack||``),P=async(e,t,n,r)=>{try{return await e(t,n,void 0,r),!1}catch(i){if(!N(i))throw i;return n.innerHTML=``,await e(t,n,void 0,{...r,renderHeaders:!1,renderFooters:!1}),!0}},te=(e,t)=>{if((e.byteLength>=4?new DataView(e).getUint16(0,!1):0)!==C)throw Error(p(t?.options)(`word.error.invalidDocx`))},F=e=>e.ownerDocument.defaultView,ne=e=>new((F(e)?.DOMParser)??globalThis.DOMParser),re=e=>{let t=[e.ownerDocument.URL,F(e)?.location?.href,globalThis.location?.href].filter(Boolean);for(let e of t)try{return new URL(e).protocol}catch{}return``},I=(e,t,n)=>{let r=Array.from(e.getElementsByTagNameNS(t,n));return r.length?r:Array.from(e.getElementsByTagName(`*`)).filter(e=>e.localName===n)},L=(e,t)=>{let n=t.parseFromString(e,`application/xml`);return I(n,`http://www.mozilla.org/newlayout/xml/parsererror.xml`,`parsererror`).length?null:n},R=(e,t)=>{let n=t.startsWith(`/`)?[]:e.split(`/`).slice(0,-1);return t.replace(/^\/+/,``).split(`/`).forEach(e=>{if(!(!e||e===`.`)){if(e===`..`){n.pop();return}n.push(e)}}),n.join(`/`)},z=e=>ee[e.split(`.`).pop()?.toLowerCase()||``],B=async(e,t=()=>new DOMParser)=>{try{let n=await g.default.loadAsync(e),r=n.file(O),i=n.file(k);if(!r||!i)return;let a=t(),o=L(await r.async(`string`),a),s=L(await i.async(`string`),a);if(!o||!s)return;let c=I(o,w,`background`)[0],l=c&&I(c,D,`fill`)[0],u=l?.getAttributeNS(T,`id`)||l?.getAttribute(`r:id`);if(!u)return;let d=I(s,E,`Relationship`).find(e=>e.getAttribute(`Id`)===u),f=d?.getAttribute(`Target`);if(!f||d?.getAttribute(`TargetMode`)===`External`)return;let p=R(O,f),m=z(p),h=n.file(p)||n.file(decodeURIComponent(p));return!m||!h?void 0:`data:${m};base64,${await h.async(`base64`)}`}catch{return}},V=(e,t)=>{if(!t)return 0;let n=0;return e.querySelectorAll(`section.docx`).forEach(r=>{let i=Array.from(r.children).find(e=>e.classList.contains(A)),a=i||e.ownerDocument.createElement(`div`);a.className=A,a.setAttribute(`aria-hidden`,`true`),a.style.backgroundImage=`url("${t}")`,i||r.prepend(a),n+=1}),n},H=(e,t)=>t?.worker===!1?!1:t?.worker===!0||!!((F(e)?.Worker??globalThis.Worker)&&t?.workerUrl&&!v.has(re(e))),U=e=>{let t=F(e)?.matchMedia??globalThis.matchMedia;return typeof t==`function`&&t(`(prefers-color-scheme: dark)`).matches},W=(e,t,n)=>{if(n?.darkMode!==void 0)return n.darkMode;let r=m(t?.options?.theme);return r===`dark`||r!==`light`&&U(e)},G=(e,t)=>!e||t?e:`${e}${e.includes(`?`)?`&`:`?`}file-viewer-docx=${S}`,K=(e,t,a)=>{let o=t?.options?.docx,s=i(e.ownerDocument),c=H(e,o),l=o?.visualPagination===!0,u=W(e,t,o),d={useWorker:c,breakPages:l,ignoreLastRenderedPageBreak:o?.ignoreLastRenderedPageBreak??!l,darkMode:u,progress:e=>{(e.phase===`render`||e.phase===`layout`||e.phase===`done`)&&a()}};return c&&(d.workerUrl=G(r(o,s),!!o?.workerUrl),d.workerJsZipUrl=G(n(o,s),!!o?.workerJsZipUrl)),o?.workerTimeout!==void 0&&(d.workerTimeout=o.workerTimeout),o?.renderPageBatchSize===void 0?o?.progressive===!1&&(d.renderPageBatchSize=2**53-1):d.renderPageBatchSize=o.renderPageBatchSize,o?.renderYieldEveryMs!==void 0&&(d.renderYieldEveryMs=o.renderYieldEveryMs),o?.strictWordCompatibility!==void 0&&(d.strictWordCompatibility=o.strictWordCompatibility),o?.paginationTolerance!==void 0&&(d.paginationTolerance=o.paginationTolerance),o?.maxDynamicPaginationPasses!==void 0&&(d.maxDynamicPaginationPasses=o.maxDynamicPaginationPasses),o?.awaitLayout!==void 0&&(d.awaitLayout=o.awaitLayout),o?.preserveComplexFieldResults!==void 0&&(d.preserveComplexFieldResults=o.preserveComplexFieldResults),o?.updatePageReferences!==void 0&&(d.updatePageReferences=o.updatePageReferences),o?.hideWebHiddenContent!==void 0&&(d.hideWebHiddenContent=o.hideWebHiddenContent),d},q=(e,t)=>{let n=F(t)?.HTMLElement;return n?e instanceof n:e instanceof HTMLElement},J=`
.docx-fit-viewer {
  box-sizing: border-box;
  height: 100%;
  overflow: auto;
  background: var(--file-viewer-render-surface-background, #ececec);
  color-scheme: light;
}
.docx-fit-viewer[data-docx-dark-mode='true'] {
  background: var(--file-viewer-render-surface-background, #242424);
  color-scheme: dark;
}
.docx-fit-viewer .docx-wrapper {
  box-sizing: border-box;
  min-width: 0 !important;
  width: 100% !important;
  padding: 24px 14px 40px !important;
  background: var(--file-viewer-render-surface-background, #e7e9ec) !important;
}
.docx-fit-viewer[data-docx-dark-mode='true'] .docx-wrapper {
  background: var(--file-viewer-render-surface-background, #242424) !important;
}
.docx-fit-viewer .docx-page-frame {
  position: relative;
  width: 100%;
  min-width: 0;
  margin: 0 auto 24px;
  overflow: visible;
}
.docx-fit-viewer .docx-flow-frame {
  position: relative;
  width: 100%;
  min-width: 0;
  margin: 0 auto 28px;
  overflow: visible;
}
.docx-fit-viewer .docx-page-frame > section.docx,
.docx-fit-viewer .docx-flow-frame > section.docx {
  position: absolute;
  top: 0;
  left: 50%;
  margin: 0 !important;
  background: #ffffff !important;
  box-shadow: 0 2px 14px rgba(25, 35, 48, 0.18);
  box-sizing: border-box;
  overflow: hidden;
  transform-origin: top center;
}
.docx-fit-viewer .docx-page-background {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
  background-position: center;
  background-repeat: no-repeat;
  background-size: 100% 100%;
}
.docx-fit-viewer[data-docx-dark-mode='true'] .docx-page-frame > section.docx,
.docx-fit-viewer[data-docx-dark-mode='true'] .docx-flow-frame > section.docx {
  background: rgb(51, 51, 51) !important;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.8);
  outline: 1px solid rgba(255, 255, 255, 0.15);
  outline-offset: -1px;
}
.docx-fit-viewer .docx-flow-frame > section.docx {
  height: auto !important;
  min-height: var(--docx-page-height, auto) !important;
  overflow: visible !important;
}
.docx-fit-viewer .docx-page-frame > section.docx > article,
.docx-fit-viewer .docx-flow-frame > section.docx > article {
  position: relative;
  z-index: 1;
}
`;function Y(e){let t=e.ownerDocument.createElement(`style`);return t.textContent=J,e.prepend(t),t}function X(e,t){let n=e.querySelector(`.docx-wrapper`);return n?Array.from(n.children).flatMap(n=>{if(!q(n,e)||!n.matches(`section.docx`))return[];let r=e.ownerDocument.createElement(`div`);return r.className=t?`docx-page-frame`:`docx-flow-frame`,n.before(r),r.appendChild(n),[r]}):[]}function ie(e,t){e.classList.add(`docx-fit-viewer`);let n=Y(e),r=t?.options?.docx?.visualPagination===!0,i=X(e,r),u=F(e),d=u?.ResizeObserver,f=0,p=1,m=1,h=1,g=o(),v=e=>Math.min(b,Math.max(y,Number(e.toFixed(2)))),S=()=>{let t=m,n=h,a=!1;i.forEach(i=>{let o=i.firstElementChild;if(!q(o,e))return;o.style.transform=`translateX(-50%)`;let s=o.offsetWidth,c=r?o.offsetHeight:Math.max(o.scrollHeight,o.offsetHeight);if(!s||!c)return;let l=Math.max(e.clientWidth-28,120),u=Math.min(1,Math.max(y,l/s)),d=v(u*p);a||=(t=d,n=u,!0),o.style.transform=`translateX(-50%) scale(${d})`,i.style.width=`${Math.ceil(Math.max(s*d,e.clientWidth-28,120))}px`,i.style.maxWidth=`none`,i.style.height=`${Math.ceil(c*d)}px`}),a&&(m=t,h=n,g.emit())},C=()=>{if(!u){S();return}u.cancelAnimationFrame(f),f=u.requestAnimationFrame(()=>{S()})},w=()=>({scale:m,label:`${Math.round(m*100)}%`,canZoomIn:m<b,canZoomOut:m>y,canReset:p!==1,minScale:y,maxScale:b}),T=e=>(p=Math.min(6,Math.max(.2,Number(e.toFixed(2)))),u?.cancelAnimationFrame(f),S(),w()),E=e=>T(e/Math.max(h,.01)),D=()=>{for(let e of i){let t=Z(e);if(!t)continue;let n=l(t,_);return{width:t.offsetWidth||n.width||_.width,height:Q(e)?_.height:t.offsetHeight||n.height||_.height}}return null},O=t=>{let n=D();if(!n)return{applied:!1,mode:t.mode,resize:t.resize,source:t.source,reason:`unmeasurable`,provider:`zoom`};let r=c({mode:t.mode===`auto`?`width`:t.mode,viewportWidth:Math.max(1,t.viewportWidth||e.clientWidth||0),viewportHeight:Math.max(1,t.viewportHeight||e.clientHeight||0),contentWidth:n.width,contentHeight:n.height,currentScale:m,minScale:t.minScale??y,maxScale:t.maxScale??b});if(!r)return{applied:!1,mode:t.mode,resize:t.resize,source:t.source,reason:`unmeasurable`,provider:`zoom`};let i=E(r);return{applied:!0,mode:t.mode,resize:t.resize,scale:i.scale,source:t.source,provider:`zoom`}};e.dataset.viewerZoomProvider=`docx`,a(e,{zoomIn:()=>T((m+x)/Math.max(h,.01)),zoomOut:()=>T((m-x)/Math.max(h,.01)),resetZoom:()=>T(1),setZoom:E,fit:O,getState:w,subscribe:g.subscribe});let k=d?new d(C):null;return k?.observe(e),i.forEach(e=>{let t=Z(e);t&&k?.observe(t)}),S(),()=>{u?.cancelAnimationFrame(f),k?.disconnect(),s(e),n.remove(),e.classList.remove(`docx-fit-viewer`)}}function Z(e){let t=e.firstElementChild,n=e.ownerDocument.defaultView?.HTMLElement;return n&&t instanceof n?t:null}function Q(e){return!!e?.classList.contains(`docx-flow-frame`)}function $(e){let t=e?Z(e):null;if(!t)return _;let n=l(t,_);return Q(e)?{width:n.width,height:Math.max(t.scrollHeight||0,t.offsetHeight||0,_.height)}:n}function ae(e,t){let n=Q(e),r=d(t.width),i=d(t.height);f(e,t,{heightMode:n?`min`:`fixed`}),e.style.margin=`0 auto 18px`;let a=Z(e);a&&(a.style.position=`relative`,a.style.top=`auto`,a.style.left=`auto`,a.style.width=r,a.style.maxWidth=`none`,a.style.minHeight=n?`0`:i,a.style.height=n?`auto`:i,a.style.margin=`0 auto`,a.style.transform=`none`,a.style.transformOrigin=`top left`,a.style.overflow=n?`visible`:`hidden`,a.style.boxShadow=`none`)}function oe(e){let t=e.querySelector(`.docx-page-frame, .docx-flow-frame`),n=$(t||void 0);return u({selector:t?.classList.contains(`docx-flow-frame`)?`.viewer-export-content .docx-flow-frame`:`.viewer-export-content .docx-page-frame`,width:n.width,height:t?.classList.contains(`docx-flow-frame`)?_.height:n.height,heightMode:t?.classList.contains(`docx-flow-frame`)?`min`:`fixed`})}function se(e){let t=Array.from(e.querySelectorAll(`.docx-page-frame, .docx-flow-frame`)),n=e.cloneNode(!0),r=e.ownerDocument.createElement(`div`);r.className=`docx-print-document`;let i=Array.from(n.querySelectorAll(`style`)).filter(e=>!e.textContent?.includes(`.docx-fit-viewer`)).map(e=>e.outerHTML).join(``);return n.querySelectorAll(`.docx-page-frame, .docx-flow-frame`).forEach((e,n)=>{e.dataset.viewerPrintPageIndex=String(n),ae(e,$(t[n])),r.appendChild(e.cloneNode(!0))}),r.childElementCount?`${i}${r.outerHTML}`:n.innerHTML}async function ce(e,t,n){var r,i;te(e,n),t.innerHTML=``;let a=!1,o=()=>{var e;a||(a=!0,(e=n?.onProgressiveRender)==null||e.call(n))},s=K(t,n,o),[{defaultOptions:c,renderAsync:l},u]=await Promise.all([M(),B(e,()=>ne(t))]);t.dataset.docxWorker=s.useWorker?`self`:`false`,t.dataset.docxDarkMode=s.darkMode?`true`:`false`;let d=await P(l,e,t,{...c,...s});t.dataset.docxHeaderFooterFallback=d?`true`:`false`,t.dataset.docxPageBackground=V(t,u)>0?`true`:`false`,o();let f=ie(t,n);return(r=n?.registerExportAdapter)==null||r.call(n,{includeDocumentStyles:!1,getPrintMaskPages:()=>Array.from(t.querySelectorAll(`.docx-page-frame, .docx-flow-frame`)),beforeSnapshot:()=>{let e=F(t);e&&e.dispatchEvent(new e.Event(`resize`))},printStyle:()=>oe(t),toHtml:()=>se(t)}),(i=n?.registerThumbnailAdapter)==null||i.call(n,{getTarget:()=>t.querySelector(`.docx-page-frame, .docx-flow-frame`)||t}),{$el:t,unmount(){var e,r;(e=n?.registerExportAdapter)==null||e.call(n,null),(r=n?.registerThumbnailAdapter)==null||r.call(n,null),f(),delete t.dataset.docxWorker,delete t.dataset.docxDarkMode,delete t.dataset.docxHeaderFooterFallback,delete t.dataset.docxPageBackground,t.innerHTML=``}}}export{ce as default};