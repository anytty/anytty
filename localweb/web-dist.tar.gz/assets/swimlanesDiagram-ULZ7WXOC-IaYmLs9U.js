import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cuv8ii2O.js";import"./chunk-I66GZJ75-DnQwT01H.js";import"./chunk-NSK5VX7P-DTseqWx6.js";import"./chunk-4I5QYGJK-Bll21f4I.js";import"./chunk-WRU74C26-CYOLN3kG.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-Dv6Zc22u.js";import"./chunk-2GRJ4B5K-DTe-VTW9.js";import"./chunk-XXDRQBXY-DIyncvop.js";import"./chunk-KBJHAD2P-Cz0Hu_Ic.js";import"./chunk-W5SLKNZC-WJcrPDuA.js";import"./chunk-QR6OTTB3-worHb9na.js";import"./chunk-7Z6QIM7H-D8fReYgH.js";import{r as t,t as n}from"./chunk-JQJVKLGR-DPCAnKmi.js";import"./mermaid.core-lk-z09Vk.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};